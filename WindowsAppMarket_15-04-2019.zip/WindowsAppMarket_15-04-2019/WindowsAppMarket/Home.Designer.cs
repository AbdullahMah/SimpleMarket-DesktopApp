﻿namespace WindowsAppMarket
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.ToString();
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CusBox = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtState = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDel = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCusPhone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCusID = new System.Windows.Forms.TextBox();
            this.txtCusName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.GridView1 = new System.Windows.Forms.DataGridView();
            this.marketDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripCusBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSaleBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripItemBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.SaleBox = new System.Windows.Forms.GroupBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.numericQty = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.btnsaleSave = new System.Windows.Forms.Button();
            this.btnsaleSearch = new System.Windows.Forms.Button();
            this.btnsaleEdit = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.btnsaleDel = new System.Windows.Forms.Button();
            this.txtnote = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtunitPrice = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.txtdailySaleId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnItem_calc = new System.Windows.Forms.Button();
            this.qty_Item = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.btnItem_Save = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnItem_Del = new System.Windows.Forms.Button();
            this.Notes_item = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ItemBox = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.itemtrackBar = new System.Windows.Forms.TrackBar();
            this.btnItem_search = new System.Windows.Forms.Button();
            this.btnItem_Edit = new System.Windows.Forms.Button();
            this.txtUnitPrice_item = new System.Windows.Forms.TextBox();
            this.txtitemName = new System.Windows.Forms.TextBox();
            this.txtitemId = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.CusBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marketDBDataSetBindingSource)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SaleBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qty_Item)).BeginInit();
            this.ItemBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // CusBox
            // 
            this.CusBox.Controls.Add(this.btnSave);
            this.CusBox.Controls.Add(this.txtState);
            this.CusBox.Controls.Add(this.btnSearch);
            this.CusBox.Controls.Add(this.btnEdit);
            this.CusBox.Controls.Add(this.label5);
            this.CusBox.Controls.Add(this.btnDel);
            this.CusBox.Controls.Add(this.txtAmount);
            this.CusBox.Controls.Add(this.label4);
            this.CusBox.Controls.Add(this.txtCusPhone);
            this.CusBox.Controls.Add(this.label3);
            this.CusBox.Controls.Add(this.txtCusID);
            this.CusBox.Controls.Add(this.txtCusName);
            this.CusBox.Controls.Add(this.label2);
            this.CusBox.Controls.Add(this.label1);
            this.CusBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CusBox.Location = new System.Drawing.Point(113, 28);
            this.CusBox.Name = "CusBox";
            this.CusBox.Size = new System.Drawing.Size(636, 235);
            this.CusBox.TabIndex = 5;
            this.CusBox.TabStop = false;
            this.CusBox.Text = "CustomerInformation";
            this.CusBox.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(456, 182);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(138, 190);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(213, 22);
            this.txtState.TabIndex = 14;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(456, 35);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(456, 82);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 11;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "CustomerState";
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(456, 129);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 23);
            this.btnDel.TabIndex = 10;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(138, 155);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(213, 22);
            this.txtAmount.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "DebitAmount";
            // 
            // txtCusPhone
            // 
            this.txtCusPhone.Location = new System.Drawing.Point(138, 116);
            this.txtCusPhone.Name = "txtCusPhone";
            this.txtCusPhone.Size = new System.Drawing.Size(213, 22);
            this.txtCusPhone.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "CustomerPhone";
            // 
            // txtCusID
            // 
            this.txtCusID.Location = new System.Drawing.Point(138, 72);
            this.txtCusID.Name = "txtCusID";
            this.txtCusID.Size = new System.Drawing.Size(213, 22);
            this.txtCusID.TabIndex = 8;
            // 
            // txtCusName
            // 
            this.txtCusName.Location = new System.Drawing.Point(138, 28);
            this.txtCusName.Name = "txtCusName";
            this.txtCusName.Size = new System.Drawing.Size(213, 22);
            this.txtCusName.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "CustomerID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "CustomerName";
            // 
            // GridView1
            // 
            this.GridView1.AutoGenerateColumns = false;
            this.GridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.GridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridView1.DataSource = this.marketDBDataSetBindingSource;
            this.GridView1.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.GridView1.Location = new System.Drawing.Point(12, 268);
            this.GridView1.Name = "GridView1";
            this.GridView1.Size = new System.Drawing.Size(891, 193);
            this.GridView1.TabIndex = 14;
            this.GridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridView1_CellContentClick);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.toolStripCusBtn,
            this.toolStripSeparator1,
            this.toolStripSaleBtn,
            this.toolStripSeparator2,
            this.toolStripItemBtn,
            this.toolStripSeparator4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(914, 25);
            this.toolStrip1.TabIndex = 15;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripCusBtn
            // 
            this.toolStripCusBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripCusBtn.ImageTransparentColor = System.Drawing.Color.Gray;
            this.toolStripCusBtn.Name = "toolStripCusBtn";
            this.toolStripCusBtn.Size = new System.Drawing.Size(129, 22);
            this.toolStripCusBtn.Text = "Customer Information";
            this.toolStripCusBtn.Click += new System.EventHandler(this.toolStripCusBtn_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSaleBtn
            // 
            this.toolStripSaleBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripSaleBtn.ImageTransparentColor = System.Drawing.Color.Gray;
            this.toolStripSaleBtn.Name = "toolStripSaleBtn";
            this.toolStripSaleBtn.Size = new System.Drawing.Size(98, 22);
            this.toolStripSaleBtn.Text = "Sale Information";
            this.toolStripSaleBtn.Click += new System.EventHandler(this.toolStripSaleBtn_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripItemBtn
            // 
            this.toolStripItemBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripItemBtn.ImageTransparentColor = System.Drawing.Color.Gray;
            this.toolStripItemBtn.Name = "toolStripItemBtn";
            this.toolStripItemBtn.Size = new System.Drawing.Size(101, 22);
            this.toolStripItemBtn.Text = "Item Information";
            this.toolStripItemBtn.Click += new System.EventHandler(this.toolStripItemBtn_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // SaleBox
            // 
            this.SaleBox.Controls.Add(this.btnCalc);
            this.SaleBox.Controls.Add(this.numericQty);
            this.SaleBox.Controls.Add(this.label6);
            this.SaleBox.Controls.Add(this.btnsaleSave);
            this.SaleBox.Controls.Add(this.btnsaleSearch);
            this.SaleBox.Controls.Add(this.btnsaleEdit);
            this.SaleBox.Controls.Add(this.label7);
            this.SaleBox.Controls.Add(this.btnsaleDel);
            this.SaleBox.Controls.Add(this.txtnote);
            this.SaleBox.Controls.Add(this.label8);
            this.SaleBox.Controls.Add(this.txtunitPrice);
            this.SaleBox.Controls.Add(this.label9);
            this.SaleBox.Controls.Add(this.txtUserID);
            this.SaleBox.Controls.Add(this.txtdailySaleId);
            this.SaleBox.Controls.Add(this.label10);
            this.SaleBox.Controls.Add(this.label11);
            this.SaleBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaleBox.Location = new System.Drawing.Point(113, 28);
            this.SaleBox.Name = "SaleBox";
            this.SaleBox.Size = new System.Drawing.Size(636, 235);
            this.SaleBox.TabIndex = 16;
            this.SaleBox.TabStop = false;
            this.SaleBox.Text = "DailySaleInformation";
            this.SaleBox.Visible = false;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(138, 189);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 21;
            this.btnCalc.Text = "Calc";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // numericQty
            // 
            this.numericQty.Location = new System.Drawing.Point(353, 116);
            this.numericQty.Name = "numericQty";
            this.numericQty.Size = new System.Drawing.Size(74, 22);
            this.numericQty.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(252, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Quantity";
            // 
            // btnsaleSave
            // 
            this.btnsaleSave.Location = new System.Drawing.Point(494, 175);
            this.btnsaleSave.Name = "btnsaleSave";
            this.btnsaleSave.Size = new System.Drawing.Size(75, 23);
            this.btnsaleSave.TabIndex = 13;
            this.btnsaleSave.Text = "Save";
            this.btnsaleSave.UseVisualStyleBackColor = true;
            this.btnsaleSave.Click += new System.EventHandler(this.btnsaleSave_Click);
            // 
            // btnsaleSearch
            // 
            this.btnsaleSearch.Location = new System.Drawing.Point(494, 28);
            this.btnsaleSearch.Name = "btnsaleSearch";
            this.btnsaleSearch.Size = new System.Drawing.Size(75, 23);
            this.btnsaleSearch.TabIndex = 12;
            this.btnsaleSearch.Text = "Search";
            this.btnsaleSearch.UseVisualStyleBackColor = true;
            this.btnsaleSearch.Click += new System.EventHandler(this.btnsaleSearch_Click);
            // 
            // btnsaleEdit
            // 
            this.btnsaleEdit.Location = new System.Drawing.Point(494, 75);
            this.btnsaleEdit.Name = "btnsaleEdit";
            this.btnsaleEdit.Size = new System.Drawing.Size(75, 23);
            this.btnsaleEdit.TabIndex = 11;
            this.btnsaleEdit.Text = "Edit";
            this.btnsaleEdit.UseVisualStyleBackColor = true;
            this.btnsaleEdit.Click += new System.EventHandler(this.btnsaleEdit_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Total Cost";
            // 
            // btnsaleDel
            // 
            this.btnsaleDel.Location = new System.Drawing.Point(494, 122);
            this.btnsaleDel.Name = "btnsaleDel";
            this.btnsaleDel.Size = new System.Drawing.Size(75, 23);
            this.btnsaleDel.TabIndex = 10;
            this.btnsaleDel.Text = "Delete";
            this.btnsaleDel.UseVisualStyleBackColor = true;
            this.btnsaleDel.Click += new System.EventHandler(this.btnsaleDel_Click);
            // 
            // txtnote
            // 
            this.txtnote.Location = new System.Drawing.Point(138, 155);
            this.txtnote.Name = "txtnote";
            this.txtnote.Size = new System.Drawing.Size(213, 22);
            this.txtnote.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Notes";
            // 
            // txtunitPrice
            // 
            this.txtunitPrice.Location = new System.Drawing.Point(138, 116);
            this.txtunitPrice.Name = "txtunitPrice";
            this.txtunitPrice.Size = new System.Drawing.Size(67, 22);
            this.txtunitPrice.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "UnitPrice";
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(138, 72);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(213, 22);
            this.txtUserID.TabIndex = 8;
            // 
            // txtdailySaleId
            // 
            this.txtdailySaleId.Location = new System.Drawing.Point(138, 28);
            this.txtdailySaleId.Name = "txtdailySaleId";
            this.txtdailySaleId.Size = new System.Drawing.Size(213, 22);
            this.txtdailySaleId.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 15);
            this.label10.TabIndex = 6;
            this.label10.Text = "UserID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(29, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "DailySaleID";
            // 
            // btnItem_calc
            // 
            this.btnItem_calc.Location = new System.Drawing.Point(138, 189);
            this.btnItem_calc.Name = "btnItem_calc";
            this.btnItem_calc.Size = new System.Drawing.Size(75, 23);
            this.btnItem_calc.TabIndex = 21;
            this.btnItem_calc.Text = "Calc";
            this.btnItem_calc.UseVisualStyleBackColor = true;
            // 
            // qty_Item
            // 
            this.qty_Item.Location = new System.Drawing.Point(353, 116);
            this.qty_Item.Name = "qty_Item";
            this.qty_Item.Size = new System.Drawing.Size(74, 22);
            this.qty_Item.TabIndex = 16;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(252, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 15);
            this.label13.TabIndex = 15;
            this.label13.Text = "Quantity";
            // 
            // btnItem_Save
            // 
            this.btnItem_Save.Location = new System.Drawing.Point(494, 175);
            this.btnItem_Save.Name = "btnItem_Save";
            this.btnItem_Save.Size = new System.Drawing.Size(75, 23);
            this.btnItem_Save.TabIndex = 13;
            this.btnItem_Save.Text = "Save";
            this.btnItem_Save.UseVisualStyleBackColor = true;
            this.btnItem_Save.Click += new System.EventHandler(this.btnItem_Save_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(29, 193);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 15);
            this.label14.TabIndex = 13;
            this.label14.Text = "Total Cost";
            // 
            // btnItem_Del
            // 
            this.btnItem_Del.Location = new System.Drawing.Point(494, 122);
            this.btnItem_Del.Name = "btnItem_Del";
            this.btnItem_Del.Size = new System.Drawing.Size(75, 23);
            this.btnItem_Del.TabIndex = 10;
            this.btnItem_Del.Text = "Delete";
            this.btnItem_Del.UseVisualStyleBackColor = true;
            this.btnItem_Del.Click += new System.EventHandler(this.btnItem_Del_Click);
            // 
            // Notes_item
            // 
            this.Notes_item.Location = new System.Drawing.Point(138, 155);
            this.Notes_item.Name = "Notes_item";
            this.Notes_item.Size = new System.Drawing.Size(289, 22);
            this.Notes_item.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 15);
            this.label15.TabIndex = 11;
            this.label15.Text = "Notes";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(29, 119);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 15);
            this.label16.TabIndex = 9;
            this.label16.Text = "UnitPrice";
            // 
            // ItemBox
            // 
            this.ItemBox.Controls.Add(this.label20);
            this.ItemBox.Controls.Add(this.label19);
            this.ItemBox.Controls.Add(this.label12);
            this.ItemBox.Controls.Add(this.itemtrackBar);
            this.ItemBox.Controls.Add(this.btnItem_calc);
            this.ItemBox.Controls.Add(this.qty_Item);
            this.ItemBox.Controls.Add(this.label13);
            this.ItemBox.Controls.Add(this.btnItem_Save);
            this.ItemBox.Controls.Add(this.btnItem_search);
            this.ItemBox.Controls.Add(this.btnItem_Edit);
            this.ItemBox.Controls.Add(this.label14);
            this.ItemBox.Controls.Add(this.btnItem_Del);
            this.ItemBox.Controls.Add(this.Notes_item);
            this.ItemBox.Controls.Add(this.label15);
            this.ItemBox.Controls.Add(this.txtUnitPrice_item);
            this.ItemBox.Controls.Add(this.label16);
            this.ItemBox.Controls.Add(this.txtitemName);
            this.ItemBox.Controls.Add(this.txtitemId);
            this.ItemBox.Controls.Add(this.label17);
            this.ItemBox.Controls.Add(this.label18);
            this.ItemBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.Location = new System.Drawing.Point(113, 28);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(636, 235);
            this.ItemBox.TabIndex = 23;
            this.ItemBox.TabStop = false;
            this.ItemBox.Text = "ItemInformation";
            this.ItemBox.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(321, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 14);
            this.label20.TabIndex = 25;
            this.label20.Text = "No";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(224, 75);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(22, 14);
            this.label19.TabIndex = 24;
            this.label19.Text = "Yes";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(138, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 15);
            this.label12.TabIndex = 23;
            this.label12.Text = "Avilability";
            // 
            // itemtrackBar
            // 
            this.itemtrackBar.LargeChange = 1;
            this.itemtrackBar.Location = new System.Drawing.Point(255, 71);
            this.itemtrackBar.Maximum = 1;
            this.itemtrackBar.Name = "itemtrackBar";
            this.itemtrackBar.Size = new System.Drawing.Size(60, 45);
            this.itemtrackBar.TabIndex = 22;
            this.itemtrackBar.Scroll += new System.EventHandler(this.itemtrackBar_Scroll);
            // 
            // btnItem_search
            // 
            this.btnItem_search.Location = new System.Drawing.Point(494, 28);
            this.btnItem_search.Name = "btnItem_search";
            this.btnItem_search.Size = new System.Drawing.Size(75, 23);
            this.btnItem_search.TabIndex = 12;
            this.btnItem_search.Text = "Search";
            this.btnItem_search.UseVisualStyleBackColor = true;
            this.btnItem_search.Click += new System.EventHandler(this.btnItem_search_Click);
            // 
            // btnItem_Edit
            // 
            this.btnItem_Edit.Location = new System.Drawing.Point(494, 75);
            this.btnItem_Edit.Name = "btnItem_Edit";
            this.btnItem_Edit.Size = new System.Drawing.Size(75, 23);
            this.btnItem_Edit.TabIndex = 11;
            this.btnItem_Edit.Text = "Edit";
            this.btnItem_Edit.UseVisualStyleBackColor = true;
            this.btnItem_Edit.Click += new System.EventHandler(this.btnItem_Edit_Click);
            // 
            // txtUnitPrice_item
            // 
            this.txtUnitPrice_item.Location = new System.Drawing.Point(138, 116);
            this.txtUnitPrice_item.Name = "txtUnitPrice_item";
            this.txtUnitPrice_item.Size = new System.Drawing.Size(67, 22);
            this.txtUnitPrice_item.TabIndex = 10;
            // 
            // txtitemName
            // 
            this.txtitemName.Location = new System.Drawing.Point(360, 28);
            this.txtitemName.Name = "txtitemName";
            this.txtitemName.Size = new System.Drawing.Size(67, 22);
            this.txtitemName.TabIndex = 8;
            // 
            // txtitemId
            // 
            this.txtitemId.Location = new System.Drawing.Point(138, 28);
            this.txtitemId.Name = "txtitemId";
            this.txtitemId.Size = new System.Drawing.Size(67, 22);
            this.txtitemId.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(252, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 15);
            this.label17.TabIndex = 6;
            this.label17.Text = "Item Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(29, 31);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 15);
            this.label18.TabIndex = 5;
            this.label18.Text = "Item ID";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 473);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.SaleBox);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.CusBox);
            this.Controls.Add(this.GridView1);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.CusBox.ResumeLayout(false);
            this.CusBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marketDBDataSetBindingSource)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.SaleBox.ResumeLayout(false);
            this.SaleBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qty_Item)).EndInit();
            this.ItemBox.ResumeLayout(false);
            this.ItemBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox CusBox;
        private System.Windows.Forms.TextBox txtCusID;
        private System.Windows.Forms.TextBox txtCusName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCusPhone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView GridView1;
        private System.Windows.Forms.BindingSource marketDBDataSetBindingSource;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripCusBtn;
        private System.Windows.Forms.ToolStripButton toolStripSaleBtn;
        private System.Windows.Forms.ToolStripButton toolStripItemBtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.GroupBox SaleBox;
        private System.Windows.Forms.NumericUpDown numericQty;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnsaleSave;
        private System.Windows.Forms.Button btnsaleSearch;
        private System.Windows.Forms.Button btnsaleEdit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnsaleDel;
        private System.Windows.Forms.TextBox txtnote;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtunitPrice;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.TextBox txtdailySaleId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnItem_calc;
        private System.Windows.Forms.NumericUpDown qty_Item;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnItem_Save;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnItem_Del;
        private System.Windows.Forms.TextBox Notes_item;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox ItemBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TrackBar itemtrackBar;
        private System.Windows.Forms.Button btnItem_search;
        private System.Windows.Forms.Button btnItem_Edit;
        private System.Windows.Forms.TextBox txtUnitPrice_item;
        private System.Windows.Forms.TextBox txtitemName;
        private System.Windows.Forms.TextBox txtitemId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
    }
}

