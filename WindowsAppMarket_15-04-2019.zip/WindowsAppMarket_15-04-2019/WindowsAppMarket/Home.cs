﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace WindowsAppMarket
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {


        }

        DataTable dt = new DataTable();
        private void GridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // >>>> Taps View <<<< //
        private void toolStripCusBtn_Click(object sender, EventArgs e)
        {
            SaleBox.Hide();
            ItemBox.Hide();
            CusBox.Show();
        }
        private void toolStripSaleBtn_Click(object sender, EventArgs e)
        {
            CusBox.Hide();
            ItemBox.Hide();
            SaleBox.Show();
        }
        private void toolStripItemBtn_Click(object sender, EventArgs e)
        {
            CusBox.Hide();
            SaleBox.Hide();
            ItemBox.Show();
        }

        // >>>> Customer Information Methods <<<< //
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string name = txtCusName.Text;
            string ID = txtCusID.Text;
            string Phone = txtCusPhone.Text;
            string Amount = txtAmount.Text;
            string State = txtState.Text;

            if (name == "" && ID == "" && Phone == "" && Amount == "" && State == "")
            {
                dt = BLLClass.CusSelectAll();
            }
            else if (name == "" && ID != "" && Phone == "" && Amount == "" && State == "")
            {
                dt = BLLClass.CusSearchbyId(ID);
            }
            else if (name != "" && ID == "" && Phone == "" && Amount == "" && State == "")
            {
                dt = BLLClass.CusSearchbyName(name);
            }
            else if (name == "" && ID == "" && Phone != "" && Amount == "" && State == "")
            {
                dt = BLLClass.CusSearchbyPhone(Phone);
            }
            else if (name == "" && ID == "" && Phone == "" && Amount == "" && State != "")
            {
                dt = BLLClass.CusSearchbyState(State);
            }
            else if (name == "" && ID == "" && Phone == "" && Amount != "" && State == "")
            {
                dt = BLLClass.CusSearchbyAmount(Amount);
            }
            GridView1.DataSource = dt;
            GridView1.AutoGenerateColumns = true;
            GridView1.DataMember = dt.ToString();
            this.GridView1.DefaultCellStyle.NullValue = "No Data";
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtCusName.Text;
            string ID = txtCusID.Text;
            string Phone = txtCusPhone.Text;
            string State = txtState.Text;
            string Amount = txtAmount.Text;

            if (name != "" && ID != "" && Phone != "" && State != "" && Amount != "")
            {
                BLLClass.CusSet(name, ID, Phone, Amount, State);
                MessageBox.Show("New Customer added successfully");
            }
            else
                MessageBox.Show("Couldn't Save New Customer! " + "Please make sure entering valid data");
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            string ID = txtCusID.Text;
            string Phone = txtCusPhone.Text;
            string State = txtState.Text;
            string Amount = txtAmount.Text;
            if (Name == "" && ID != "" || Phone != "" || Amount != "" || State != "")
            {
                BLLClass.CusEdit(ID, Phone, Amount, "", "", State);
                MessageBox.Show("Customer was Editted successfully");
            }
            else
            {
                MessageBox.Show("Couldn't Edit Customer Data! " + "Please make sure entering valid data");
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string ID = txtCusID.Text;
            if (ID != "")
            {
                BLLClass.CusDel(ID);
                MessageBox.Show("Customer data was Deleted successfully");
            }
            else
            {
                MessageBox.Show("Couldn't Delete Customer Data! " + "Please make sure entering valid Customer ID");
            }
        }

        // >>>> Daily Sale Information Methods <<<< //
        private void btnsaleSearch_Click(object sender, EventArgs e)
        {
            string SaleId = txtdailySaleId.Text;
            string UserId = txtUserID.Text;
            string UnitPrice = txtunitPrice.Text;
            string Quantity = numericQty.Value.ToString();
            if (SaleId == "" && UserId == "" && UnitPrice == "" && Quantity == "0")
            {
                dt = BLLClass.dailySale_SelectAll();
            }
            else if (SaleId != "" && UserId == "" && UnitPrice == "" && Quantity == "0")
            {
                dt = BLLClass.dailySale_SelBySaleId(SaleId);
            }
            else if (SaleId == "" && UserId != "" && UnitPrice == "" && Quantity == "0")
            {
                dt = BLLClass.dailySale_SelByUserId(UserId);
            }
            else if (SaleId == "" && UserId == "" && UnitPrice != "" && Quantity == "0")
            {
                dt = BLLClass.dailySale_SelByUnitPrice(UnitPrice);
            }
            else if (SaleId == "" && UserId == "" && UnitPrice == "" && Quantity != "0")
            {
                dt = BLLClass.dailySale_SelByQty(Quantity);
            }
            GridView1.DataSource = dt;
            GridView1.AutoGenerateColumns = true;
            GridView1.DataMember = dt.ToString();
            this.GridView1.DefaultCellStyle.NullValue = "No Data";
        }
        private void btnsaleEdit_Click(object sender, EventArgs e)
        {
            string SaleId = txtdailySaleId.Text;
            string UserId = txtUserID.Text;
            string UnitPrice = txtunitPrice.Text;
            string Quantity = numericQty.Value.ToString();
            string Notes = txtnote.Text;
            if (SaleId != "" || UserId != "" || UnitPrice != "" || Quantity != "0" && Notes == "Edited")
            {
                BLLClass.dailySaleEdit(SaleId, DateTime.Now.ToShortTimeString(), UserId, UnitPrice, Quantity, Notes);
                MessageBox.Show(" Daily Sale was Edited Successfully");
            }
            else
            MessageBox.Show("Couldn't Edit Daily Sale ! " + "Please make sure entering valid data");
        }
        private void btnsaleDel_Click(object sender, EventArgs e)
        {
            string SaleId = txtdailySaleId.Text;
            if (SaleId != "")
            {
                BLLClass.dailySaleDel(SaleId);
                MessageBox.Show("Daily Sale was Deleated Successfully");
            }
            else
                MessageBox.Show("Couldn't Delete Daily Sale Data! " + "Please make sure entering valid Daily Sale ID");
        }
        private void btnsaleSave_Click(object sender, EventArgs e)
        {
            string SaleId = txtdailySaleId.Text;
            string UserId = txtUserID.Text;
            string UnitPrice = txtunitPrice.Text;
            string Quantity = numericQty.Value.ToString();
            string Notes = txtnote.Text;
            if (SaleId != "" && UserId != "" && UnitPrice != "" && Quantity != "0")
            {
                BLLClass.dailySaleNew(SaleId, DateTime.Now.ToShortTimeString(), DateTime.Now.ToShortDateString(), UserId, UnitPrice, Quantity, Notes);
                MessageBox.Show("Daily Sale was Saved Successfully");
            }
            else
                MessageBox.Show("Couldn't Save Daily Sale ! " + "Please make sure entering valid data");
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            string UnitPrice = txtunitPrice.Text;
            string Quantity = numericQty.Value.ToString();
            string cost = (int.Parse(UnitPrice) * int.Parse(Quantity)).ToString();
            MessageBox.Show("Total cost = " + cost);
        }

        // >>>> Item Information Methods <<<< //
        private void btnItem_calc_Click(object sender, EventArgs e)
        {
            string Item_qty = qty_Item.Value.ToString();
            string Item_Cost = txtUnitPrice_item.Text;
            string CostItem = (int.Parse(Item_qty) * int.Parse(Item_Cost)).ToString();
            MessageBox.Show("Item Cost = " + CostItem);
        }
        private void itemtrackBar_Scroll(object sender, EventArgs e)
        {
            string itemBar_state = itemtrackBar.Value.ToString();
            if (itemBar_state == "1")
            {
                label13.Hide();
                label16.Hide();
                txtUnitPrice_item.Hide();
                qty_Item.Hide();
                label14.Hide();
                btnItem_calc.Hide();
            }
            else if (itemBar_state == "0")
            {
                label13.Show();
                label16.Show();
                txtUnitPrice_item.Show();
                qty_Item.Show();
                label14.Show();
                btnItem_calc.Show();
            }
        }
        private void btnItem_Save_Click(object sender, EventArgs e)
        {
            string ItemName = txtitemName.Text;
            string ItemId = txtitemId.Text;
            string ItemPrice = txtUnitPrice_item.Text;
            string ItemQty = qty_Item.Value.ToString();
            string Notes = Notes_item.Text;
            if (ItemName != "" && ItemId != "" && ItemPrice != "" && ItemQty != "0")
            {
                BLLClass.New_item(ItemId, ItemName, ItemPrice, ItemQty, Notes);
                MessageBox.Show("Item Saved Successfully");
            }
            else
                MessageBox.Show("Couldn't Save New Item! " +  "Please make sure entering valid data");
        }
        private void btnItem_Edit_Click(object sender, EventArgs e)
        {
            string ItemName = txtitemName.Text;
            string ItemId = txtitemId.Text;
            string ItemPrice = txtUnitPrice_item.Text;
            string ItemQty = qty_Item.Value.ToString();
            string Notes = Notes_item.Text;
            if (ItemName == "" && ItemId != "" && ItemPrice != "" && ItemQty != "0")
            {
                BLLClass.Edit_item(ItemId, ItemPrice, ItemQty, Notes);
                MessageBox.Show("Item was Edited Successfully");
            }
            else
                MessageBox.Show("Couldn't Edit Item Data ! " + "Please make sure entering valid Item ID");
        }
        private void btnItem_Del_Click(object sender, EventArgs e)
        {
            string ItemId = txtitemId.Text;
            if (ItemId != "" )
            {
                BLLClass.Delete_item(ItemId);
                MessageBox.Show("Item was Deleted Successfully");
            }
            else
                MessageBox.Show("Couldn't Delete Item Data ! " + "Please make sure entering valid Item ID");
        }
        private void btnItem_search_Click(object sender, EventArgs e)
        {
            string ItemName = txtitemName.Text;
            string ItemId = txtitemId.Text;
            string ItemPrice = txtUnitPrice_item.Text;
            string ItemQty = qty_Item.Value.ToString();
            string Notes = Notes_item.Text;
            if (ItemName == "" && ItemId == "" && ItemPrice == "" && ItemQty == "0")
            {
                dt = BLLClass.SelectAll_Items();
            }
            else if(ItemName == "" && ItemId != "" && ItemPrice == "" && ItemQty == "0")
            {
                dt = BLLClass.SelectAll_Items_byId(ItemId);
            }
            else if (ItemName != "" && ItemId == "" && ItemPrice == "" && ItemQty == "0")
            {
                dt = BLLClass.SelectAll_Items_byName(ItemName);
            }
            else if (ItemName == "" && ItemId == "" && ItemPrice != "" && ItemQty == "0")
            {
                dt = BLLClass.SelectAll_Items_byPrice(ItemPrice);
            }
            GridView1.DataSource = dt;
            GridView1.AutoGenerateColumns = true;
            GridView1.DataMember = dt.ToString();
            this.GridView1.DefaultCellStyle.NullValue = "No Data";
        }
    }
}
