﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsAppMarket
{
    class BLLClass
    {
        // >>>> Customer Information Methods <<<< //
        public static DataTable CusSearchbyId(string cus_id)
        {

            DataTable SelcusById = new DataTable();
            try
            {
                return DALClass.SelectCustomerbyId(cus_id);

            }
            catch (Exception e)
            { }
            return SelcusById;
        }
        public static DataTable CusSearchbyName(string cus_name)
        {

            DataTable SelcusByname = new DataTable();
            try
            {
                return DALClass.SelectCustomerbyName(cus_name);

            }
            catch (Exception e)
            { }
            return SelcusByname;
        }
        public static DataTable CusSearchbyPhone(string cus_phone)
        {

            DataTable SelcusByPhone = new DataTable();
            try
            {
                return DALClass.SelectCustomerbyPhone(cus_phone);

            }
            catch (Exception e)
            { }
            return SelcusByPhone;
        }
        public static DataTable CusSearchbyState(string cus_state)
        {

            DataTable SelcusByState = new DataTable();
            try
            {
                return DALClass.SelectCustomerbyState(cus_state);

            }
            catch (Exception e)
            { }
            return SelcusByState;
        }
        public static DataTable CusSearchbyAmount(string cus_debt)
        {

            DataTable SelcusByDebt = new DataTable();
            try
            {
                return DALClass.SelectCustomerbyAmount(cus_debt);

            }
            catch (Exception e)
            { }
            return SelcusByDebt;
        }
        public static DataTable CusSelectAll()
        {
            DataTable SelAllCus = new DataTable();
            try
            {
                return DALClass.SelectallCustomer();
            }
            catch (Exception e)
            { }
            return SelAllCus;
        }
        public static bool CusSet(string name, string id, string phone, string debt, string state)
        {
            try
            {
                return DALClass.NewCustomer(id, name, phone, debt, state);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static bool CusEdit(string id, string phone, string debt, string change, string recomm, string state)
        {
            try
            {
                DALClass.EditCustomerData(id, phone, debt, change, recomm, state);
            }
            catch (Exception e)
            {

            }
            return false;

        }
        public static bool CusDel(string cusId)
        {
            try
            {
                return DALClass.DeleteCustomerData(cusId);
            }
            catch (Exception e)
            {

            }
            return false;
        }

        // >>>> Daily Sale Information Methods <<<< //
        public static DataTable dailySale_SelectAll()
        {

            DataTable SelAllSales = new DataTable();
            try
            {
                return DALClass.SelectallDailySale();

            }
            catch (Exception e)
            { }
            return SelAllSales;
        }
        public static DataTable dailySale_SelByUserId(string userid)
        {

            DataTable SelAllSales = new DataTable();
            try
            {
                return DALClass.SelectDailySale_byuserId(userid);

            }
            catch (Exception e)
            { }
            return SelAllSales;
        }
        public static DataTable dailySale_SelBySaleId(string Saleid)
        {

            DataTable SelAllSales = new DataTable();
            try
            {
                return DALClass.SelectDailySale_bysaleId(Saleid);

            }
            catch (Exception e)
            { }
            return SelAllSales;
        }
        public static DataTable dailySale_SelByQty(string quantity)
        {

            DataTable SelAllSales = new DataTable();
            try
            {
                return DALClass.SelectDailySale_byQty(quantity);

            }
            catch (Exception e)
            { }
            return SelAllSales;
        }
        public static DataTable dailySale_SelByUnitPrice(string unitprice)
        {

            DataTable SelAllSales = new DataTable();
            try
            {
                return DALClass.SelectDailySale_byunitPrice(unitprice);

            }
            catch (Exception e)
            { }
            return SelAllSales;
        }
        public static bool dailySaleDel(string Saleid)
        {
            try
            {
                return DALClass.DeleteDailySale(Saleid);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static bool dailySaleEdit(string Saleid, string time, string userId, string unitPrice, string qty, string notes )
        {
            try
            {
                return DALClass.EditDailySale(Saleid, time, userId, unitPrice, qty, notes);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static bool dailySaleNew(string Saleid, string time, string date, string userId, string unitPrice, string qty, string notes)
        {
            try
            {
                return DALClass.NewDailySale(Saleid, time, date, userId, unitPrice, qty, notes);
            }
            catch (Exception e)
            {

            }
            return false;
        }

        // >>>> Item Information Methods <<<< //
        public static bool New_item(string itemId, string itemName, string itemPrice, string item_Qty, string Note)
        {
            try
            {
                return DALClass.NewItem(itemId, itemName, itemPrice, item_Qty, Note);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static bool Edit_item(string itemId, string itemPrice, string item_Qty, string Note)
        {
            try
            {
                return DALClass.EditItem(itemId, itemPrice, item_Qty, Note);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static bool Delete_item(string itemId)
        {
            try
            {
                return DALClass.DeleteItem(itemId);
            }
            catch (Exception e)
            {

            }
            return false;
        }
        public static DataTable SelectAll_Items()
        {
            DataTable SelAll_items = new DataTable();
            try
            {
                return DALClass.SelectallItems();
            }
            catch (Exception e)
            { }
            return SelAll_items;
        }
        public static DataTable SelectAll_Items_byId(string Item_id)
        {
            DataTable SelAll_items = new DataTable();
            try
            {
                return DALClass.SelectItems_byId(Item_id);
            }
            catch (Exception e)
            { }
            return SelAll_items;
        }
        public static DataTable SelectAll_Items_byName(string Item_name)
        {
            DataTable SelAll_items = new DataTable();
            try
            {
                return DALClass.SelectItems_byName(Item_name);
            }
            catch (Exception e)
            { }
            return SelAll_items;
        }
        public static DataTable SelectAll_Items_byPrice(string Item_price)
        {
            DataTable SelAll_items = new DataTable();
            try
            {
                return DALClass.SelectItems_byprice(Item_price);
            }
            catch (Exception e)
            { }
            return SelAll_items;
        }

    }
}
