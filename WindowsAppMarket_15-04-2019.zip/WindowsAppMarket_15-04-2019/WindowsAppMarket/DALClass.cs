﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsAppMarket
{
    class DALClass
    {
        // *** Customer Table SQL Commands *** //
        public static bool NewCustomer(string customerID, string customerName, string customerPhone, string debt, string state)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO CustomerTable (CustomerID, CustomerName, CustomerPhone, Debt, Recommidation, CustomerState) VALUES(@customerID, @customerName, @customerPhone, @debt, @Recomm, @customerState)", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@customerID", customerID);
                cmd.Parameters.AddWithValue("@customerName", customerName);
                cmd.Parameters.AddWithValue("@customerPhone", customerPhone);
                cmd.Parameters.AddWithValue("@customerstate", state);
                cmd.Parameters.AddWithValue("@debt", debt);
                cmd.Parameters.AddWithValue("@Recomm", "New Customer");
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool EditCustomerData(string customerID, string customerPhone, string debt, string change, string Recomm, string state)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE CustomerTable SET CustomerPhone = @customerPhone, Debt = @debt, Change = @change, Recommidation = @Recomm, CustomerState = @state WHERE CustomerID = @customerID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@customerID", customerID);
                cmd.Parameters.AddWithValue("@customerPhone", customerPhone);
                cmd.Parameters.AddWithValue("@debt", debt);
                cmd.Parameters.AddWithValue("@change", "change it");
                cmd.Parameters.AddWithValue("@Recomm", "Edit your recommmendation");
                cmd.Parameters.AddWithValue("@state", state);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool DeleteCustomerData(string customerID)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM CustomerTable WHERE CustomerID = @customerID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@customerID", customerID);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static DataTable SelectallCustomer()
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source = HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable ORDER BY CustomerID", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_customer_data;
        }
        public static DataTable SelectCustomerbyId(string customerID)
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable WHERE CustomerID = @customerID ORDER BY CustomerID", con);
                cmd.Parameters.AddWithValue("@customerID", customerID);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Erorr ");
            }
            return dt_customer_data;
        }
        public static DataTable SelectCustomerbyName(string customerName)
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable WHERE CustomerName = @customername ORDER BY CustomerName", con);
                cmd.Parameters.AddWithValue("@customername", customerName);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Erorr ");
            }
            return dt_customer_data;
        }
        public static DataTable SelectCustomerbyPhone(string customerPhone)
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable WHERE CustomerPhone = @customerphone ORDER BY CustomerName", con);
                cmd.Parameters.AddWithValue("@customerphone", customerPhone);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Erorr ");
            }
            return dt_customer_data;
        }
        public static DataTable SelectCustomerbyState(string customerState)
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable WHERE CustomerState = @customerstate ORDER BY CustomerName", con);
                cmd.Parameters.AddWithValue("@customerstate", customerState);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Erorr ");
            }
            return dt_customer_data;
        }
        public static DataTable SelectCustomerbyAmount(string customerAmount)
        {
            DataTable dt_customer_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM CustomerTable WHERE Debt = @customeramount ORDER BY CustomerName", con);
                cmd.Parameters.AddWithValue("@customeramount", customerAmount);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_customer_data);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Erorr ");
            }
            return dt_customer_data;
        }

        // *** DailySales Table SQL Commands *** //
        public static bool NewDailySale(string dailysaleId, string dailysaleTime, string dailysaledate, string userId, string unitPrice, string quantity, string Note)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO DailySalesTable (DailySaleID, OerationTime, OperationDate, UserID, unitPrice, Quantity, Notes) VALUES(@dailySailID, @oerationTime, @operationDate, @userID, @unitPrice, @quantity, @note)", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@dailySailID", dailysaleId);
                cmd.Parameters.AddWithValue("@oerationTime", Convert.ToDateTime(dailysaleTime));
                cmd.Parameters.AddWithValue("@operationDate", Convert.ToDateTime(dailysaledate));
                cmd.Parameters.AddWithValue("@userID", userId);
                cmd.Parameters.AddWithValue("@unitPrice", unitPrice);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.Parameters.AddWithValue("@note", Note);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool EditDailySale(string dailysaleId, string dailysaleTime,  string userId, string unitPrice, string quantity, string Note)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE DailySalesTable SET OerationTime = @oerationTime, UserID = @userID, unitPrice = @unitPrice, Quantity = @quantity, Notes=@note WHERE DailySaleID = @dailySailID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@dailySailID", dailysaleId);
                cmd.Parameters.AddWithValue("@oerationTime", Convert.ToDateTime(dailysaleTime));
                cmd.Parameters.AddWithValue("@userID", userId);
                cmd.Parameters.AddWithValue("@unitPrice", unitPrice);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.Parameters.AddWithValue("@note", Note);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool DeleteDailySale(string dailysaleId)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM DailySalesTable WHERE DailySaleID = @dailySailID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@dailySailID", dailysaleId);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static DataTable SelectallDailySale()
        {
            DataTable dt_dailysale_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DailySalesTable ORDER BY DailySaleID", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_dailysale_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_dailysale_data;
        }
        public static DataTable SelectDailySale_bysaleId(string dailysaleId)
        {
            DataTable dt_dailysale_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DailySalesTable WHERE DailySaleID = @dailySailID ORDER BY DailySaleID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@dailySailID", dailysaleId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_dailysale_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_dailysale_data;
        }
        public static DataTable SelectDailySale_byuserId(string userId)
        {
            DataTable dt_dailysale_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DailySalesTable WHERE UserID = @UserId ORDER BY DailySaleID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@UserId", userId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_dailysale_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_dailysale_data;
        }
        public static DataTable SelectDailySale_byQty(string quantity)
        {
            DataTable dt_dailysale_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DailySalesTable WHERE Quantity = @quantity ORDER BY DailySaleID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@quantity", quantity);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_dailysale_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_dailysale_data;
        }
        public static DataTable SelectDailySale_byunitPrice(string unitPrice)
        {
            DataTable dt_dailysale_data = new DataTable();

            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DailySalesTable WHERE unitPrice = @unitPrice ORDER BY DailySaleID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@unitPrice", unitPrice);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_dailysale_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_dailysale_data;
        }

        // *** item Table SQL Commands *** //
        public static bool NewItem(string itemId, string itemName, string itemPrice, string item_Qty, string Note)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO itemTable (itemID, itemName, unitPrice, Quantity, Notes) VALUES(@ItemId, @ItemName, @unitPrice, @quantity, @note)", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ItemName", itemName);
                cmd.Parameters.AddWithValue("@ItemId", itemId);
                cmd.Parameters.AddWithValue("@unitPrice", itemPrice);
                cmd.Parameters.AddWithValue("@quantity", item_Qty);
                cmd.Parameters.AddWithValue("@note", Note);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool EditItem(string itemId, string itemPrice, string item_Qty, string Note)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE itemTable SET itemID = @ItemId, unitPrice = @unitPrice, Quantity = @quantity, Notes=@note WHERE itemID = @ItemId", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ItemId", itemId);
                cmd.Parameters.AddWithValue("@unitPrice", itemPrice);
                cmd.Parameters.AddWithValue("@quantity", item_Qty);
                cmd.Parameters.AddWithValue("@note", Note);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static bool DeleteItem(string itemId)
        {
            int result = 0;
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString); con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM itemTable WHERE itemID = @itemId", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@itemId", itemId);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return false;

        }
        public static DataTable SelectallItems()
        {
            DataTable dt_item_data = new DataTable();
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM itemTable ORDER BY itemID", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_item_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_item_data;
        }
        public static DataTable SelectItems_byId(string itemId)
        {
            DataTable dt_item_data = new DataTable();
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM itemTable WHERE itemID = @itemId ORDER BY itemID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@itemId", itemId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_item_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_item_data;
        }
        public static DataTable SelectItems_byName(string itemName)
        {
            DataTable dt_item_data = new DataTable();
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM itemTable WHERE itemName = @itemName ORDER BY itemID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@itemName", itemName);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_item_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_item_data;
        }
        public static DataTable SelectItems_byprice(string itemPrice)
        {
            DataTable dt_item_data = new DataTable();
            try
            {
                string connetionString;
                SqlConnection con;
                connetionString = @"Data Source=HP\SQLEXPRESS; Initial Catalog=MarketDB; Integrated Security=True";
                con = new SqlConnection(connetionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM itemTable WHERE unitPrice = @unitPrice ORDER BY itemID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@unitPrice", itemPrice);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt_item_data);
                con.Close();
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
            }
            return dt_item_data;
        }

    }
}
